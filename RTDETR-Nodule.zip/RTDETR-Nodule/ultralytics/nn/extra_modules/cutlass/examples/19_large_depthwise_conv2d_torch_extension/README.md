Torch Extension for DepthwiseConv2d with Implicit GEMM
---

### Usage

Compile and install `depthwise_conv2d_implicit_gemm`

```
./setup.py install --user
```

